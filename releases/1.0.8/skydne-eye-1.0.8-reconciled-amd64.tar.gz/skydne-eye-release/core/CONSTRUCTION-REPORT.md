# Isolated construction handoff

## Scope and state

Canonical candidate workspace: this isolated directory; its local absolute path is recorded in the external handoff, not reusable source. The original reference application and authoritative audit remain separate. This is a partially implemented construction candidate, **not** a completed canonical production release. Current version is `1.0.0-rc.1`; no v1.0.0 tag, Git repository, commit, remote or push was created.

The full product/source structure is described in README.md. Source families include 5,670 initially extracted files/links, with an upstream example-private-key README subsequently excluded. Source traceability, template derivations and newly authored tools are recorded separately. No production database rows, recordings, AI images, keys, site INI or logs were imported.

All **40 audited locally modified web files remain byte-identical**. The UI/source reference has 2,280 entries after excluding that non-UI vendor README: 2,278 remain exact, and two otherwise unmodified backend probe files have explicit environment-based credential changes. No stylesheet, layout, icons, navigation, playback presentation or ALPR HTML template was edited. Strict all-file comparison reports those two differences; the explicit configuration-boundary check verifies their separately recorded candidate hashes. Visual/functional equivalence is not certified by hashes alone.

## Security and Git

Working-tree filename/content/symlink pattern scan: PASS with three narrow hash-pinned upstream exceptions. The broader UID-0 location scan checked 22 protected values and identified 640 overlaps in 100 files, all for one value; the other 21 did not occur. Context review found ordinary role/account/path/prose usages as well as credential uses in an upstream preset and historical account seed. The credential uses were sanitized; four literal Host constructions in the same two probe files were also externalized. Benign overlaps are pinned to exact file hashes and byte ranges for a final fresh privileged check. **Overall secret clearance remains HOLD until that validation**, and Git initialization/staging is withheld. Exact staged-content scan: NOT RUN. Local commit hash: NOT CREATED.

`REPOSITORY-SAFETY-REPORT.md` records the boundary, exclusions and required next gates. The upstream default admin seed was removed; local provisioning is required. Factory camera-probe credentials were externalized, not copied into safe templates. The existing reference is untouched, including its documented source-network camera failures.

## Dependencies

Exact observed version selection contains **654 Debian packages**, including virtual-provider selections, **31 Python distributions**, four model/config hashes, Java 8u492, NVIDIA driver expectations and native platform identity. Only four selected Debian packages have exact matching cached files (the curl family). The required underlying video platform package is not among them. Package dependency constraint validation, signed-origin evidence, remaining package acquisition, wheel filenames/hashes, pristine Java/Pharos artifacts and model provenance/licensing remain incomplete. No newer package was substituted or installed.

`deploy/artifacts.py` refuses missing hashes/filenames or mismatches and only fetches a supplied reviewed HTTPS URL when explicitly requested. It is not a resolver for a moving latest version. Corresponding native surveillance runtime source/build provenance is still unavailable. These are real reproducibility blockers.

## Tooling and tests

Implemented `install.sh`, `upgrade.sh`, `backup.sh`, `restore.sh`, `rollback.sh`, `health-check.sh` wrap a guarded **isolated-root** lifecycle engine. It supports version validation, immutable staging, payload health checks, encrypted pre-upgrade backup, compatible pointer rollback without rewinding new database rows, result logging, consistent SQLite snapshots, optional private-socket MariaDB dumps, validated empty-target restoration and recording exclusion.

Host installation is **not implemented to activation readiness**: `host-plan.py` is a read-only preflight and fails closed; the isolated wrappers must not be represented as a finished fresh-server installer. Pending host work includes dependency installation policy, complete local admin/product-default provisioning, release/native-web path activation, service restart orchestration, full migration runner/ledger, hardware and model-cache setup, interrupted-operation recovery and production-grade health coverage. Service/configuration templates and ownership mappings are proposals requiring disposable-host validation. New ALPR service and reconstructed Pinggy behavior are not production-certified.

Executed validations:

- Python syntax for new tools and ALPR/ops; PHP syntax for both edited backend files.
- UI reference verification with the two explicit configuration exceptions; all 40 audited web modifications unchanged.
- Encrypted synthetic backup/restore of site configuration, release metadata and SQLite state, including a nested ALPR database.
- Synthetic upgrade with mandatory pre-upgrade backup, compatible rollback retaining post-upgrade rows, missing-backup refusal, nonempty-restore refusal, escaping-symlink refusal, recording sentinel preserved and omitted from archive.
- Independent socket-only MariaDB restore: 50 tables (49 packaged tables plus synthetic fixture), all 12 triggers, synthetic data, ALPR SQLite schema and local test configuration recovered into a second disposable instance. Production MariaDB was not accessed by this test.

These tests do not validate real application login/UI/API/AI recognition, production backup completeness, host package rollback or clean installation. Transient test processes were started only for synthetic databases/GnuPG; no production services were restarted or stopped.

## Readiness

| Gate | Result |
|---|---|
| Secrets cleared for first commit | HOLD — contextual sanitization/review complete; fresh privileged snapshot validation pending |
| Exact staged-content scan | NOT RUN — Git gate withheld |
| Dependencies reproducible | FAIL — missing immutable artifacts/provenance |
| Reference UI captured | PASS — all 40 local modifications unchanged; two explicit credential-boundary exceptions elsewhere |
| Packaged database schema captured | PASS — no production contents; generic product-default review incomplete |
| AI/ALPR source captured | PASS — GPU/runtime acquisition and service parity pending |
| Backup successful | PASS — encrypted isolated fixtures only |
| Restore tested | PASS — isolated MariaDB/SQLite/config fixtures only |
| Host installer ready | FAIL — planner/templates plus tested isolated engine, host activation incomplete |
| Clean install tested | FAIL — not performed |
| Functional parity tested | FAIL — not performed |
| Browser/UI parity tested | FAIL — not performed |
| Production release ready | FAIL |

## Next bounded steps

1. Finish protected known-value comparison and resolve any contextual matches without printing secrets. Repeat working-tree/independent scans after all edits. Do not initialize/stage/commit until clearance.
2. Obtain authenticated exact surveillance runtime and GPU/Python/Java/Pharos artifacts and model permissions. Pin every selected artifact; do not follow latest branches or silently substitute builds.
3. Complete generic presentation/menu defaults and local credential/bootstrap configuration; finish host installer/migration/health orchestration against a disposable host, not the reference system.
4. Run clean installation, failure/restore/rollback and functional/browser parity acceptance. Only then consider a production tag and later authorized publication/deployment.
