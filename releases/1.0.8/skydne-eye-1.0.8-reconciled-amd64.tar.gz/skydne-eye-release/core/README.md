> Latest checkpoint: [real CPU acceptance result](docs/cpu-acceptance-result.md). Guarded CPU acceptance passed, including real reboot and desktop/mobile browser checks. Production and reference parity remain unqualified.

# Skydne Eye — isolated v1.0.0 construction candidate

Version: **1.0.0-rc.1**. This workspace is not a production release and has completed guarded CPU acceptance on an initially clean disposable host. Development changes are published to `origin/main`; no production release tag is authorized.

The product is the audited native surveillance runtime 1.39.10 implementation with captured PHP/JavaScript/CSS/assets, Perl camera integration and separate GPU ALPR. Preserve the existing UI and workflows; this is not a rewrite. Site configuration, credentials, camera records, databases, recordings, AI media and operational logs stay outside the repository.

```text
app/zoneminder/       captured web/backend, Perl and native management scripts
app/alpr/            local-recording GPU ALPR and unchanged HTML template
ops/                 parameterized operational scripts and local status contract
config/              placeholder templates for local site/secret configuration
database/            captured upstream schema/migrations, ALPR schema, compatibility
deploy/              isolated lifecycle tools, host planner, artifact verification, units
locks/               exact observed versions; missing artifact hashes remain explicit
provenance/          source/candidate hashes, UI reference and reviewed code changes
release/             scans, byte-parity verification and fail-closed readiness gates
modules/             stable Core/optional-module manifests and compatibility metadata
tests/               synthetic encrypted backup/restore and lifecycle validation
docs/                installation acceptance, recovery and local operations
LICENSES/            upstream attribution
```

Start with `REPOSITORY-SAFETY-REPORT.md` and `docs/clean-install-test.md`. Read the explicit limitations before using deployment scripts. `deploy/install.sh`, `upgrade.sh`, `backup.sh`, `restore.sh`, `rollback.sh` and `health-check.sh` currently wrap the **isolated-root engine**, not a finished production host installer. `deploy/host-plan.py` is read-only and refuses the existing reference installation. It will not upgrade packages or restart services.

Real CPU acceptance now covers synthetic recording/playback, service restart and reboot, encrypted database recovery, packaging upgrade/rollback and mount-loss refusal. The six-view authorized Sambhrama screenshot comparison and Core server/runtime functional comparison pass. This does not establish production recovery or full release readiness.
The reference and corrected Samruddhi captures match for Console, Live View, Event Detail, Montage Review, Events and Options after aligning the US-English and no-thumbnail clean-host defaults. Camera pixels, fixture identifiers, storage topology, PTZ capability and optional-module content are excluded. Pages absent from the supplied reference remain NOT COMPARED.

The authorized 2026-09-11 Sambhrama pass captured a private masked login reference and verified 574 installed UI assets against the frozen copy with zero mismatches. The deterministic `+skydne3` Core package includes the dpkg-verified `default.zmfnt`; Samruddhi installation, hash/permissions, native startup and browser checks passed. A guarded MPEG-TS A/B isolated the passthrough failure and verified explicit H.264 encoding; subsequent recording, decode, live view and browser playback checks passed on Samruddhi. Production was not changed.

The installer entry point supports `--prepare-site` for private local placeholders and `--check-host` for read-only preflight. See [site preparation](docs/site-preparation.md) and [validation evidence](docs/framework-validation.md). These modes do not activate the application.

No code path in the isolated lifecycle engine contacts cameras, moves CCTV media or changes host services. Operational scripts are captured/reconstructed product code that can perform their normal operations **if installed and executed**; do not run them against production while reviewing this candidate.

The first physical-key modular installer architecture is documented in [docs/modular-installer.md](docs/modular-installer.md). It is isolated-test ready; it is not authorization to reinstall Samruddhi or a production release.

UI verification:

```sh
python3 release/verify-ui.py
python3 release/verify-ui.py --allow-reviewed-config-boundaries
python3 release/scan.py
```

Strict source parity reports the two backend camera-probe configuration changes; the explicit second mode verifies their recorded candidate hashes and leaves all other files pinned to the reference. No layout/style/assets/template change is hidden by that exception. Scoped browser and functional parity results are recorded separately.
