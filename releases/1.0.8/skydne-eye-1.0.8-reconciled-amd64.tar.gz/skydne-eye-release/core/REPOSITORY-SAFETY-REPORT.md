# Repository safety report — candidate, not publication clearance

Overall result: **FAIL / HOLD**. No Git initialization, staging, commit, tag, remote configuration or push is authorized by the checks completed so far. The working tree is an isolated construction candidate, not an approved first-commit payload.

| Check | Result | Evidence / limit |
|---|---|---|
| Explicit audited extraction | PASS | Source hashes checked before copying; provenance manifests retain original and derived hashes |
| Runtime/backup/recording/database-content selection | PASS for extraction | Only audited source families and safe reconstructed templates selected; no live databases, recordings, AI media or site config copied |
| Full working-tree filename/content pattern scan | PASS | `release/scan.py` reads every file byte, including vendor files and source maps, and examines symlink targets; no size-based skipping |
| Independent site/literal/known-value scan | Limited check only | Unprivileged check covered three known values; it cannot clear the broader protected findings |
| Actual protected production/camera credentials compared | CONTEXT REVIEW COMPLETE; final validation pending | UID-0 location scan checked 22 values with no collection errors. All 640 overlaps came from one value. Credential uses were sanitized; remaining matches are pinned to exact reviewed file hashes and byte locations |
| Exact staged-content scan | NOT RUN | Git initialization is intentionally withheld until safety clearance |
| Private keys | PASS pattern check | No private-key payload detected; upstream JWT example-key documentation was excluded rather than committed |
| Site names/addresses | PASS for refactored operations | Site network inventory, user/home names, camera IDs and public tunnel URL removed from ops; generic upstream subnet examples are not customer inventory |
| Safe templates | PASS for candidate inspection | Secret/site fields contain placeholders or protected local file references; no production .env/INI/unit copied verbatim |
| UI reference traceability | PASS with explicit configuration boundaries | Original file hashes retained; no styles/layout/assets/template edits; two backend probe files externalize factory credential literals |
| Publication/release readiness | FAIL | Safety oracle, exact dependencies, host installer, fresh-install and functional/UI acceptance remain incomplete |

Three narrow, file-hash-pinned pattern exceptions are documented in `release/reviewed-scan-exceptions.json`: the bundled **public** CA trust certificates (not private material), unchanged upstream synthetic HTTP test fixtures, and the password-compat library's public bcrypt self-test vector. Private keys and known production-secret findings cannot be waived by the scanner. A future file change invalidates each exception. The original upstream default administrator seed was removed from `database/upstream/zm_create.sql`; a unique local administrator must be provisioned later.

The privileged location scan found 640 occurrences in 100 files, all for one protected value; the other 21 produced no matches. Context review distinguished ordinary account identifiers, roles, routes, code identifiers, translated prose, source-path metadata and synthetic test usernames from credential fields. Genuine password uses in a packaged preset and historical account seed were removed. Four remaining literal credential-bearing Host constructions across the same two backend probe files now read local environment configuration. No styles, layout, navigation or audited modified web files were changed by this review.

The external `reviewed-nonsecret-contexts.json` pins reviewed benign occurrences to complete file hashes and exact byte ranges. It is not a password-length rule, a whole-file exception or permission to ignore future uses of that value. The final root scan must reload the protected values, scan the current candidate and reject any unmatched/unreviewed occurrence or changed file. A final exact snapshot and staged-blob check are still required before Git clearance. The raw FAIL result remains preserved in the private audit; it is not rewritten to claim no matches existed.

The independent scanner initially overmatched a nonsecret SSH environment setting; that extraction rule was narrowed and the scan rerun. Neither unreviewed matches nor zero regex findings establish clearance. Exact selected/index-byte review is still required after working-tree clearance.

Outside Git by design: all production configuration and environment files, camera/user/session/Config database contents, SQL dumps and historical tables, CCTV recordings and existing recording backups, AI SQLite/state/media/logs/keys, operational logs/journals, backup archives, SSH/SSL/CA/Pinggy credentials and identity state, Tailscale/AnyDesk/Pharos site state, cache/venv/.pydeps, downloaded packages/wheels/model binaries, shell history and private audit topology. The exact installed package versions and binary hashes may be represented as generic lock metadata, not site state.

The candidate does contain **packaged generic schema/migrations**, static image/font/audio assets, frontend `dist`/TypeScript assets and bundled PHP/Perl libraries. These are product code, not customer data. `.gitignore` is adapted accordingly; it does not globally ignore all images, `.ts` files or vendor build assets. The sole permitted PEM file is the pinned public CA bundle. No whole live directory is a staging source.

Before Git: finalize this report against the privileged result; repeat both scans after edits; approve an explicit file manifest; initialize only this isolated directory; stage the allowlist; compare index bytes/modes against the cleared candidate; run `release/scan.py --staged` (which reads blobs and exception policy from the index); inspect the staged path list. Only then may a local commit be created. No remote/push/tag in this phase.
