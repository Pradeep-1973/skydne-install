# Changelog

## 1.0.0-rc.1 — isolated construction candidate

- Capture the audited installed web, PHP, Perl, schema and ALPR implementation.
- Preserve the existing UI bytes and record reference hashes.
- Externalize local ALPR configuration and operational network/camera/tunnel settings.
- Add offline artifact validation, isolated deployment lifecycle tooling, backup/restore tests and release gates.
- Add the isolated physical-USB authorization gate, signed modular release format, module lifecycle, bootstrap and status CLI architecture.

Not a production release. No v1.0.0 tag, fresh-install certification, UI redesign or camera repairs.
