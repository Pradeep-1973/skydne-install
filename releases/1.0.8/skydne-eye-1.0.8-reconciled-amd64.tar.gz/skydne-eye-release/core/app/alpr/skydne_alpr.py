#!/usr/bin/env python3
"""GPU ALPR and plate-log service for the SkyDne Eye Gate Camera.

The worker reads completed byte-range fragments from ZoneMinder's local,
already-recording fMP4 file. It never connects to the camera RTSP endpoint.
"""

from __future__ import annotations

import configparser
import csv
import hashlib
import io
import json
import logging
import os
import re
import secrets
import shutil
import sqlite3
import statistics
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import parse_qs, urlparse

import cv2
import numpy as np
import onnxruntime as ort
from fast_alpr import ALPR
from flask import (
    Flask,
    Response,
    abort,
    jsonify,
    make_response,
    redirect,
    render_template,
    request,
    send_from_directory,
    url_for,
)
from waitress import serve


APP_ROOT = Path(__file__).resolve().parent
CONFIG_PATH = Path(os.environ.get("SKYDNE_ALPR_CONFIG", "/etc/skydne-eye/alpr.ini"))
LOG = logging.getLogger("skydne-alpr")
PLATE_CLEAN_RE = re.compile(r"[^A-Z0-9]")
INDIA_PATTERNS = [
    re.compile(r"^[A-Z]{2}[0-9]{1,2}[A-Z]{1,3}[0-9]{4}$"),
    re.compile(r"^[0-9]{2}BH[0-9]{4}[A-Z]{1,2}$"),
]


@dataclass(frozen=True)
class Segment:
    event_id: int
    playlist: Path
    source: Path
    init_length: int
    init_offset: int
    length: int
    offset: int
    duration: float
    event_started_at: float

    @property
    def key(self) -> str:
        return f"{self.event_id}:{self.offset}:{self.length}"

    @property
    def frame_time_base(self) -> float:
        return self.event_started_at + max(0.0, self.offset_seconds)

    @property
    def offset_seconds(self) -> float:
        # Filled from the manifest parser through event_started_at adjustment.
        return 0.0


class Settings:
    def __init__(self, path: Path):
        parser = configparser.ConfigParser()
        if not parser.read(path):
            raise RuntimeError(f"Configuration not found: {path}")
        self.parser = parser
        self.monitor_id = parser.getint("service", "monitor_id")
        self.monitor_name = parser.get("service", "monitor_name")
        self.event_root = Path(parser.get("service", "event_root"))
        self.data_dir = Path(parser.get("service", "data_dir"))
        self.host = parser.get("service", "host")
        self.port = parser.getint("service", "port")
        self.timezone = parser.get("service", "timezone")
        self.poll_seconds = parser.getfloat("service", "poll_seconds")
        self.startup_segments = parser.getint("service", "startup_segments")
        self.detector_model = parser.get("recognition", "detector_model")
        self.detector_confidence = parser.getfloat("recognition", "detector_confidence")
        self.ocr_confidence = parser.getfloat("recognition", "ocr_confidence")
        self.min_plate_length = parser.getint("recognition", "min_plate_length")
        self.max_plate_length = parser.getint("recognition", "max_plate_length")
        self.sample_fps = parser.getfloat("recognition", "sample_fps")
        self.consensus_hits = parser.getint("recognition", "consensus_hits")
        self.consensus_window = parser.getfloat("recognition", "consensus_window_seconds")
        self.dedupe_seconds = parser.getfloat("recognition", "dedupe_seconds")
        self.roi_top = parser.getfloat("recognition", "roi_top")
        self.roi_bottom = parser.getfloat("recognition", "roi_bottom")
        self.tile_width = parser.getfloat("recognition", "tile_width")
        self.tile_overlap = parser.getfloat("recognition", "tile_overlap")
        self.jpeg_quality = parser.getint("recognition", "jpeg_quality")
        self.retention_days = parser.getint("retention", "days")
        self.max_snapshots_mb = parser.getint("retention", "max_snapshots_mb")
        self.cleanup_interval = parser.getint("retention", "cleanup_interval_minutes") * 60
        self.event_url = parser.get("zoneminder", "event_url")
        self.dashboard_url = parser.get("zoneminder", "dashboard_url")


class Store:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.db_path = settings.data_dir / "plates.sqlite3"
        self.snapshot_dir = settings.data_dir / "snapshots"
        self.temp_dir = settings.data_dir / "tmp"
        self.snapshot_dir.mkdir(parents=True, exist_ok=True)
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._init_db()

    def connect(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self.db_path, timeout=15, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA busy_timeout=15000")
            self._local.conn = conn
        return conn

    def _init_db(self) -> None:
        conn = sqlite3.connect(self.db_path)
        conn.executescript(
            """
            PRAGMA journal_mode=WAL;
            PRAGMA synchronous=NORMAL;
            CREATE TABLE IF NOT EXISTS detections (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plate TEXT NOT NULL,
                plate_normalized TEXT NOT NULL,
                first_seen TEXT NOT NULL,
                last_seen TEXT NOT NULL,
                confidence REAL NOT NULL,
                detector_confidence REAL NOT NULL,
                region TEXT,
                monitor_id INTEGER NOT NULL,
                event_id INTEGER NOT NULL,
                hits INTEGER NOT NULL,
                frame_width INTEGER NOT NULL,
                frame_height INTEGER NOT NULL,
                bbox_json TEXT NOT NULL,
                vehicle_image TEXT NOT NULL,
                plate_image TEXT NOT NULL,
                india_format INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_detections_seen
                ON detections(first_seen DESC);
            CREATE INDEX IF NOT EXISTS idx_detections_plate
                ON detections(plate_normalized);
            CREATE INDEX IF NOT EXISTS idx_detections_event
                ON detections(event_id);
            CREATE TABLE IF NOT EXISTS health (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS processed_segments (
                segment_key TEXT PRIMARY KEY,
                processed_at TEXT NOT NULL
            );
            """
        )
        conn.commit()
        conn.close()

    def set_health(self, **values: Any) -> None:
        now = iso_now()
        conn = self.connect()
        conn.executemany(
            """
            INSERT INTO health(key,value,updated_at) VALUES(?,?,?)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at
            """,
            [(key, json.dumps(value), now) for key, value in values.items()],
        )
        conn.commit()

    def health(self) -> dict[str, Any]:
        rows = self.connect().execute("SELECT key,value,updated_at FROM health").fetchall()
        result: dict[str, Any] = {}
        latest = None
        for row in rows:
            try:
                result[row["key"]] = json.loads(row["value"])
            except json.JSONDecodeError:
                result[row["key"]] = row["value"]
            latest = max(latest or row["updated_at"], row["updated_at"])
        result["health_updated_at"] = latest
        return result

    def segment_done(self, key: str) -> bool:
        return (
            self.connect()
            .execute("SELECT 1 FROM processed_segments WHERE segment_key=?", (key,))
            .fetchone()
            is not None
        )

    def mark_segment(self, key: str) -> None:
        conn = self.connect()
        conn.execute(
            "INSERT OR IGNORE INTO processed_segments(segment_key,processed_at) VALUES(?,?)",
            (key, iso_now()),
        )
        conn.commit()

    def recent_duplicate(self, plate: str, seen_at: datetime) -> sqlite3.Row | None:
        cutoff = (seen_at - timedelta(seconds=self.settings.dedupe_seconds)).isoformat()
        return self.connect().execute(
            """
            SELECT * FROM detections
            WHERE plate_normalized=? AND last_seen>=?
            ORDER BY last_seen DESC LIMIT 1
            """,
            (plate, cutoff),
        ).fetchone()

    def save_detection(self, item: dict[str, Any]) -> int:
        conn = self.connect()
        duplicate = self.recent_duplicate(item["plate_normalized"], item["seen_at"])
        if duplicate:
            replace_images = item["confidence"] > duplicate["confidence"]
            conn.execute(
                """
                UPDATE detections SET
                    last_seen=?, confidence=MAX(confidence,?),
                    detector_confidence=MAX(detector_confidence,?),
                    hits=hits+?, updated_at=?,
                    vehicle_image=CASE WHEN ? THEN ? ELSE vehicle_image END,
                    plate_image=CASE WHEN ? THEN ? ELSE plate_image END,
                    bbox_json=CASE WHEN ? THEN ? ELSE bbox_json END,
                    event_id=CASE WHEN ? THEN ? ELSE event_id END
                WHERE id=?
                """,
                (
                    item["seen_at"].isoformat(),
                    item["confidence"],
                    item["detector_confidence"],
                    item["hits"],
                    iso_now(),
                    replace_images,
                    item["vehicle_image"],
                    replace_images,
                    item["plate_image"],
                    replace_images,
                    item["bbox_json"],
                    replace_images,
                    item["event_id"],
                    duplicate["id"],
                ),
            )
            conn.commit()
            return int(duplicate["id"])

        cursor = conn.execute(
            """
            INSERT INTO detections(
                plate,plate_normalized,first_seen,last_seen,confidence,
                detector_confidence,region,monitor_id,event_id,hits,
                frame_width,frame_height,bbox_json,vehicle_image,plate_image,
                india_format,created_at,updated_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                item["plate"],
                item["plate_normalized"],
                item["seen_at"].isoformat(),
                item["seen_at"].isoformat(),
                item["confidence"],
                item["detector_confidence"],
                item["region"],
                item["monitor_id"],
                item["event_id"],
                item["hits"],
                item["frame_width"],
                item["frame_height"],
                item["bbox_json"],
                item["vehicle_image"],
                item["plate_image"],
                int(item["india_format"]),
                iso_now(),
                iso_now(),
            ),
        )
        conn.commit()
        return int(cursor.lastrowid)

    def query(self, search: str = "", date_from: str = "", date_to: str = "", limit: int = 200):
        clauses: list[str] = []
        params: list[Any] = []
        if search:
            clauses.append("plate_normalized LIKE ?")
            params.append(f"%{normalize_plate(search)}%")
        if date_from:
            clauses.append("first_seen >= ?")
            params.append(f"{date_from}T00:00:00")
        if date_to:
            clauses.append("first_seen < ?")
            params.append((datetime.fromisoformat(date_to) + timedelta(days=1)).isoformat())
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(min(max(limit, 1), 1000))
        return self.connect().execute(
            f"SELECT * FROM detections {where} ORDER BY first_seen DESC LIMIT ?", params
        ).fetchall()

    def stats(self) -> dict[str, int]:
        row = self.connect().execute(
            """
            SELECT
                COUNT(*) total,
                SUM(CASE WHEN first_seen>=date('now','localtime') THEN 1 ELSE 0 END) today,
                COUNT(DISTINCT plate_normalized) unique_plates
            FROM detections
            """
        ).fetchone()
        return {key: int(row[key] or 0) for key in row.keys()}

    def cleanup(self) -> None:
        cutoff = datetime.now().astimezone() - timedelta(days=self.settings.retention_days)
        conn = self.connect()
        old_rows = conn.execute(
            "SELECT vehicle_image,plate_image FROM detections WHERE first_seen<?",
            (cutoff.isoformat(),),
        ).fetchall()
        conn.execute("DELETE FROM detections WHERE first_seen<?", (cutoff.isoformat(),))
        conn.execute(
            "DELETE FROM processed_segments WHERE processed_at<?",
            ((datetime.now().astimezone() - timedelta(days=7)).isoformat(),),
        )
        conn.commit()
        for row in old_rows:
            for column in ("vehicle_image", "plate_image"):
                safe_unlink(self.snapshot_dir / row[column])

        max_bytes = self.settings.max_snapshots_mb * 1024 * 1024
        files = sorted(
            (p for p in self.snapshot_dir.rglob("*.jpg") if p.is_file()),
            key=lambda p: p.stat().st_mtime,
        )
        total = sum(p.stat().st_size for p in files)
        for path in files:
            if total <= max_bytes:
                break
            size = path.stat().st_size
            safe_unlink(path)
            total -= size


class Consensus:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.pending: dict[str, deque[dict[str, Any]]] = defaultdict(deque)

    def observe(self, observation: dict[str, Any]) -> dict[str, Any] | None:
        now = observation["seen_at"].timestamp()
        key = observation["plate_normalized"]
        queue = self.pending[key]
        queue.append(observation)
        while queue and now - queue[0]["seen_at"].timestamp() > self.settings.consensus_window:
            queue.popleft()
        if len(queue) < self.settings.consensus_hits:
            return None
        best = max(queue, key=lambda item: item["confidence"])
        best = dict(best)
        best["hits"] = len(queue)
        queue.clear()
        return best

    def expire(self) -> None:
        now = time.time()
        for key in list(self.pending):
            queue = self.pending[key]
            while queue and now - queue[0]["seen_at"].timestamp() > self.settings.consensus_window:
                queue.popleft()
            if not queue:
                del self.pending[key]


class AlprWorker(threading.Thread):
    daemon = True

    def __init__(self, settings: Settings, store: Store):
        super().__init__(name="gate-alpr-worker")
        self.settings = settings
        self.store = store
        self.stop_event = threading.Event()
        self.consensus = Consensus(settings)
        self.model: ALPR | None = None
        self.segments_processed = 0
        self.frames_processed = 0
        self.inference_samples: deque[float] = deque(maxlen=200)
        self.last_cleanup = 0.0
        self._initialised_playlist: Path | None = None

    def initialise_model(self) -> None:
        ort.preload_dlls(directory="")
        providers = ort.get_available_providers()
        if "CUDAExecutionProvider" not in providers:
            raise RuntimeError(f"CUDAExecutionProvider unavailable; providers={providers}")
        self.model = ALPR(
            detector_model=self.settings.detector_model,
            detector_conf_thresh=self.settings.detector_confidence,
            detector_providers=["CUDAExecutionProvider"],
            ocr_device="cuda",
            ocr_providers=["CUDAExecutionProvider"],
        )
        detector_providers = self.model.detector.detector.model.get_providers()
        ocr_providers = self.model.ocr.ocr_model.model.get_providers()
        if detector_providers[0] != "CUDAExecutionProvider" or ocr_providers[0] != "CUDAExecutionProvider":
            raise RuntimeError(
                f"GPU assertion failed: detector={detector_providers}, ocr={ocr_providers}"
            )
        self.store.set_health(
            state="running",
            gpu_enabled=True,
            last_error=None,
            last_error_at=None,
            detector_provider=detector_providers[0],
            ocr_provider=ocr_providers[0],
            detector_model=self.settings.detector_model,
            started_at=iso_now(),
            source_mode="ZoneMinder local completed fMP4 fragments (no RTSP connection)",
        )

    def run(self) -> None:
        try:
            self.initialise_model()
        except Exception as exc:
            LOG.exception("Unable to initialise GPU ALPR")
            self.store.set_health(state="failed", gpu_enabled=False, last_error=str(exc))
            return

        while not self.stop_event.is_set():
            try:
                playlist = newest_playlist(self.settings)
                if playlist:
                    segments = parse_manifest(playlist)
                    self._prime_or_process(playlist, segments)
                self.consensus.expire()
                if time.time() - self.last_cleanup >= self.settings.cleanup_interval:
                    self.store.cleanup()
                    self.last_cleanup = time.time()
                self._publish_health(playlist if playlist else None)
            except Exception as exc:
                LOG.exception("Worker cycle failed")
                self.store.set_health(last_error=str(exc), last_error_at=iso_now())
            self.stop_event.wait(self.settings.poll_seconds)

    def _prime_or_process(self, playlist: Path, segments: list[Segment]) -> None:
        if playlist != self._initialised_playlist:
            unseen = [segment for segment in segments if not self.store.segment_done(segment.key)]
            for segment in unseen[: -self.settings.startup_segments]:
                self.store.mark_segment(segment.key)
            self._initialised_playlist = playlist
        for segment in segments:
            if self.stop_event.is_set():
                break
            if self.store.segment_done(segment.key):
                continue
            if segment.source.stat().st_size < segment.offset + segment.length:
                continue
            try:
                self.process_segment(segment)
            finally:
                self.store.mark_segment(segment.key)

    def process_segment(self, segment: Segment) -> None:
        temp_path = self.store.temp_dir / f"{segment.event_id}-{segment.offset}.mp4"
        with segment.source.open("rb") as source, temp_path.open("wb") as target:
            source.seek(segment.init_offset)
            target.write(source.read(segment.init_length))
            source.seek(segment.offset)
            target.write(source.read(segment.length))

        capture = cv2.VideoCapture(str(temp_path))
        if not capture.isOpened():
            safe_unlink(temp_path)
            raise RuntimeError(f"Unable to decode fragment {segment.key}")
        native_fps = capture.get(cv2.CAP_PROP_FPS) or 15.0
        frame_step = max(1, round(native_fps / self.settings.sample_fps))
        frame_index = 0
        decoded = 0
        while True:
            ok, frame = capture.read()
            if not ok:
                break
            decoded += 1
            if frame_index % frame_step == 0:
                seconds = frame_index / native_fps
                seen_at = datetime.fromtimestamp(
                    segment.event_started_at + seconds, tz=datetime.now().astimezone().tzinfo
                )
                self.process_frame(frame, segment.event_id, seen_at)
            frame_index += 1
        capture.release()
        safe_unlink(temp_path)
        self.segments_processed += 1
        LOG.debug("Processed segment %s (%d decoded frames)", segment.key, decoded)

    def process_frame(self, frame: np.ndarray, event_id: int, seen_at: datetime) -> None:
        assert self.model is not None
        height, width = frame.shape[:2]
        y1 = max(0, int(height * self.settings.roi_top))
        y2 = min(height, int(height * self.settings.roi_bottom))
        tile_width = int(width * self.settings.tile_width)
        step = max(1, int(tile_width * (1.0 - self.settings.tile_overlap)))
        starts = list(range(0, max(1, width - tile_width + 1), step))
        if not starts or starts[-1] + tile_width < width:
            starts.append(max(0, width - tile_width))

        seen_boxes: list[tuple[int, int, int, int]] = []
        for x1 in starts:
            x2 = min(width, x1 + tile_width)
            tile = frame[y1:y2, x1:x2]
            started = time.perf_counter()
            results = self.model.predict(tile)
            self.inference_samples.append((time.perf_counter() - started) * 1000)
            for result in results:
                bbox = result.detection.bounding_box
                box = (bbox.x1 + x1, bbox.y1 + y1, bbox.x2 + x1, bbox.y2 + y1)
                if any(iou(box, existing) > 0.55 for existing in seen_boxes):
                    continue
                seen_boxes.append(box)
                observation = self.make_observation(
                    frame, result, box, event_id, seen_at, width, height
                )
                if observation is None:
                    continue
                accepted = self.consensus.observe(observation)
                if accepted:
                    detection_id = self.store.save_detection(accepted)
                    LOG.info(
                        "Plate accepted id=%s plate=%s confidence=%.3f event=%s",
                        detection_id,
                        accepted["plate_normalized"],
                        accepted["confidence"],
                        event_id,
                    )
        self.frames_processed += 1

    def make_observation(
        self,
        frame: np.ndarray,
        result: Any,
        box: tuple[int, int, int, int],
        event_id: int,
        seen_at: datetime,
        width: int,
        height: int,
    ) -> dict[str, Any] | None:
        if result.ocr is None:
            return None
        plate = normalize_plate(result.ocr.text)
        if not (self.settings.min_plate_length <= len(plate) <= self.settings.max_plate_length):
            return None
        confidence_values = result.ocr.confidence
        if isinstance(confidence_values, list):
            confidence = statistics.fmean(confidence_values) if confidence_values else 0.0
        else:
            confidence = float(confidence_values or 0.0)
        if confidence < self.settings.ocr_confidence:
            return None

        x1, y1, x2, y2 = clamp_box(box, width, height)
        if x2 <= x1 or y2 <= y1:
            return None
        pad_x = max(40, int((x2 - x1) * 3.5))
        pad_y = max(30, int((y2 - y1) * 3.0))
        vehicle_box = clamp_box(
            (x1 - pad_x, y1 - pad_y, x2 + pad_x, y2 + pad_y), width, height
        )
        vehicle = frame[vehicle_box[1] : vehicle_box[3], vehicle_box[0] : vehicle_box[2]].copy()
        plate_crop = frame[y1:y2, x1:x2].copy()

        stamp = seen_at.strftime("%Y%m%d-%H%M%S-%f")
        digest = hashlib.sha1(f"{plate}-{event_id}-{stamp}".encode()).hexdigest()[:10]
        day_dir = self.store.snapshot_dir / seen_at.strftime("%Y-%m-%d")
        day_dir.mkdir(parents=True, exist_ok=True)
        vehicle_name = f"{seen_at:%Y-%m-%d}/{stamp}-{plate}-{digest}-vehicle.jpg"
        plate_name = f"{seen_at:%Y-%m-%d}/{stamp}-{plate}-{digest}-plate.jpg"
        cv2.imwrite(
            str(self.store.snapshot_dir / vehicle_name),
            vehicle,
            [cv2.IMWRITE_JPEG_QUALITY, self.settings.jpeg_quality],
        )
        cv2.imwrite(
            str(self.store.snapshot_dir / plate_name),
            plate_crop,
            [cv2.IMWRITE_JPEG_QUALITY, min(96, self.settings.jpeg_quality + 4)],
        )
        return {
            "plate": result.ocr.text,
            "plate_normalized": plate,
            "seen_at": seen_at,
            "confidence": confidence,
            "detector_confidence": float(result.detection.confidence),
            "region": result.ocr.region,
            "monitor_id": self.settings.monitor_id,
            "event_id": event_id,
            "hits": 1,
            "frame_width": width,
            "frame_height": height,
            "bbox_json": json.dumps({"x1": x1, "y1": y1, "x2": x2, "y2": y2}),
            "vehicle_image": vehicle_name,
            "plate_image": plate_name,
            "india_format": any(pattern.fullmatch(plate) for pattern in INDIA_PATTERNS),
        }

    def _publish_health(self, playlist: Path | None) -> None:
        average = statistics.fmean(self.inference_samples) if self.inference_samples else 0.0
        self.store.set_health(
            state="running",
            gpu_enabled=True,
            monitor_id=self.settings.monitor_id,
            monitor_name=self.settings.monitor_name,
            last_poll_at=iso_now(),
            active_playlist=str(playlist) if playlist else None,
            active_event_id=event_id_from_path(playlist) if playlist else None,
            segments_processed=self.segments_processed,
            frames_processed=self.frames_processed,
            average_tile_inference_ms=round(average, 2),
            sample_fps=self.settings.sample_fps,
            source_network_connections=0,
        )


def parse_manifest(playlist: Path) -> list[Segment]:
    text = playlist.read_text(errors="replace")
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    map_match = re.search(r'#EXT-X-MAP:URI="([^"]+)",BYTERANGE="(\d+)@(\d+)"', text)
    if not map_match:
        return []
    map_uri, init_length, init_offset = map_match.groups()
    event_id = event_id_from_path(playlist)
    if event_id is None:
        return []
    start_time = playlist.parent.stat().st_ctime
    date_match = re.search(r"/(\d{4}-\d{2}-\d{2})/", str(playlist))
    if date_match:
        # Event directory ctime is more precise; date path is only a sanity fallback.
        start_time = playlist.parent.stat().st_ctime

    segments: list[Segment] = []
    duration = 0.0
    pending_duration = 0.0
    pending_range: tuple[int, int] | None = None
    for line in lines:
        if line.startswith("#EXTINF:"):
            pending_duration = float(line.split(":", 1)[1].rstrip(","))
        elif line.startswith("#EXT-X-BYTERANGE:"):
            value = line.split(":", 1)[1]
            length_text, offset_text = value.split("@", 1)
            pending_range = (int(length_text), int(offset_text))
        elif not line.startswith("#") and pending_range:
            parsed = parse_qs(urlparse(line).query)
            filename = parsed.get("file", [Path(map_uri).name])[0]
            source = playlist.parent / filename
            if source.exists():
                segments.append(
                    Segment(
                        event_id=event_id,
                        playlist=playlist,
                        source=source,
                        init_length=int(init_length),
                        init_offset=int(init_offset),
                        length=pending_range[0],
                        offset=pending_range[1],
                        duration=pending_duration,
                        event_started_at=start_time + duration,
                    )
                )
            duration += pending_duration
            pending_duration = 0.0
            pending_range = None
    return segments


def newest_playlist(settings: Settings) -> Path | None:
    monitor_root = settings.event_root / str(settings.monitor_id)
    candidates: list[Path] = []
    now = datetime.now()
    for day in (now, now - timedelta(days=1)):
        day_root = monitor_root / day.strftime("%Y-%m-%d")
        if not day_root.exists():
            continue
        candidates.extend(day_root.glob("*/index.m3u8"))
    if not candidates:
        return None
    return max(candidates, key=lambda path: path.stat().st_mtime)


def event_id_from_path(path: Path | None) -> int | None:
    if path is None:
        return None
    try:
        return int(path.parent.name)
    except ValueError:
        return None


def normalize_plate(value: str) -> str:
    return PLATE_CLEAN_RE.sub("", (value or "").upper())


def iso_now() -> str:
    return datetime.now().astimezone().isoformat()


def clamp_box(
    box: tuple[int, int, int, int], width: int, height: int
) -> tuple[int, int, int, int]:
    x1, y1, x2, y2 = box
    return max(0, x1), max(0, y1), min(width, x2), min(height, y2)


def iou(first: tuple[int, int, int, int], second: tuple[int, int, int, int]) -> float:
    x1 = max(first[0], second[0])
    y1 = max(first[1], second[1])
    x2 = min(first[2], second[2])
    y2 = min(first[3], second[3])
    intersection = max(0, x2 - x1) * max(0, y2 - y1)
    if not intersection:
        return 0.0
    first_area = max(0, first[2] - first[0]) * max(0, first[3] - first[1])
    second_area = max(0, second[2] - second[0]) * max(0, second[3] - second[1])
    return intersection / max(1, first_area + second_area - intersection)


def safe_unlink(path: Path) -> None:
    try:
        path.unlink(missing_ok=True)
    except OSError:
        LOG.warning("Unable to remove %s", path, exc_info=True)


def load_or_create_access_key(data_dir: Path) -> str:
    path = data_dir / "access_key"
    if path.exists():
        return path.read_text().strip()
    value = secrets.token_urlsafe(32)
    path.write_text(value)
    path.chmod(0o600)
    return value


def create_web(settings: Settings, store: Store, access_key: str) -> Flask:
    app = Flask(__name__, template_folder=str(APP_ROOT / "templates"), static_folder=None)
    app.secret_key = hashlib.sha256(access_key.encode()).digest()

    def authorised() -> bool:
        supplied = request.args.get("key", "")
        cookie = request.cookies.get("skydne_alpr_access", "")
        expected = hashlib.sha256(access_key.encode()).hexdigest()
        return secrets.compare_digest(cookie, expected) or secrets.compare_digest(supplied, access_key)

    def require_access(function):
        @wraps(function)
        def wrapped(*args, **kwargs):
            if not authorised():
                return (
                    "<h1>SkyDne Eye Plate Log</h1><p>Open this page from the authenticated "
                    "SkyDne Eye navigation menu.</p>",
                    403,
                )
            response = make_response(function(*args, **kwargs))
            if request.args.get("key"):
                response.set_cookie(
                    "skydne_alpr_access",
                    hashlib.sha256(access_key.encode()).hexdigest(),
                    httponly=True,
                    samesite="Lax",
                    max_age=30 * 24 * 3600,
                )
            return response

        return wrapped

    @app.after_request
    def security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["Cache-Control"] = "no-store"
        return response

    @app.get("/")
    @require_access
    def index():
        if request.args.get("key"):
            response = redirect(url_for("index"))
            response.set_cookie(
                "skydne_alpr_access",
                hashlib.sha256(access_key.encode()).hexdigest(),
                httponly=True,
                samesite="Lax",
                max_age=30 * 24 * 3600,
            )
            return response
        rows = store.query(
            request.args.get("q", ""),
            request.args.get("from", ""),
            request.args.get("to", ""),
            250,
        )
        detections = [dict(row) for row in rows]
        for item in detections:
            item["event_url"] = settings.event_url.format(event_id=item["event_id"])
        return render_template(
            "index.html",
            detections=detections,
            stats=store.stats(),
            health=store.health(),
            settings=settings,
            query=request.args,
        )

    @app.get("/snapshots/<path:filename>")
    @require_access
    def snapshot(filename: str):
        return send_from_directory(store.snapshot_dir, filename)

    @app.get("/api/health")
    @require_access
    def api_health():
        return jsonify(store.health())

    @app.get("/api/detections")
    @require_access
    def api_detections():
        rows = store.query(request.args.get("q", ""), limit=request.args.get("limit", 100, type=int))
        return jsonify([dict(row) for row in rows])

    @app.get("/export.csv")
    @require_access
    def export_csv():
        rows = store.query(
            request.args.get("q", ""),
            request.args.get("from", ""),
            request.args.get("to", ""),
            1000,
        )
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(
            [
                "plate",
                "first_seen",
                "last_seen",
                "ocr_confidence",
                "detector_confidence",
                "hits",
                "india_format",
                "monitor_id",
                "event_id",
            ]
        )
        for row in rows:
            writer.writerow(
                [
                    row["plate_normalized"],
                    row["first_seen"],
                    row["last_seen"],
                    row["confidence"],
                    row["detector_confidence"],
                    row["hits"],
                    row["india_format"],
                    row["monitor_id"],
                    row["event_id"],
                ]
            )
        return Response(
            output.getvalue(),
            mimetype="text/csv",
            headers={"Content-Disposition": "attachment; filename=skydne-eye-plate-log.csv"},
        )

    @app.get("/healthz")
    def healthz():
        health = store.health()
        status = 200 if health.get("state") == "running" and health.get("gpu_enabled") else 503
        return jsonify({"state": health.get("state"), "gpu": health.get("gpu_enabled")}), status

    return app


def configure_logging(settings: Settings) -> None:
    log_dir = settings.data_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
        handlers=[
            logging.FileHandler(log_dir / "service.log"),
            logging.StreamHandler(),
        ],
    )


def main() -> None:
    os.environ.setdefault("CUDA_VISIBLE_DEVICES", "0")
    os.environ.setdefault("OMP_NUM_THREADS", "2")
    settings = Settings(CONFIG_PATH)
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    configure_logging(settings)
    access_key = load_or_create_access_key(settings.data_dir)
    store = Store(settings)
    worker = AlprWorker(settings, store)
    worker.start()
    app = create_web(settings, store, access_key)
    LOG.info("Plate Log listening on %s:%s", settings.host, settings.port)
    serve(app, host=settings.host, port=settings.port, threads=4, channel_timeout=30)


if __name__ == "__main__":
    main()
